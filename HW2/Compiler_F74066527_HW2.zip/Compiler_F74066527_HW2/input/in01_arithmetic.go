var x int32
var y int32
x + y
x - y
x * y
x / y
x % y
x++
x--